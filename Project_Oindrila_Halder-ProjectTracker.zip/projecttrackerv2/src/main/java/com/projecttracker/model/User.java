package com.projecttracker.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "hr" ,name = "USER420")
public class User {
    
	@Id
	private int userId;
	@Column
	private String name;
	@Column
	private String designation;
	@Column
	private String gender;
	@Column
	private String email;
	@Column
	private int phoneNo;
	@Column
	private String password;
	@Column
	private int leader_Status;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public int getLeader_Status() {
		return leader_Status;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int isLeader_Status() {
		return leader_Status;
	}
	public void setLeader_Status(int leader_Status) {
		this.leader_Status = leader_Status;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", designation=" + designation + ", gender=" + gender
				+ ", email=" + email + ", phoneNo=" + phoneNo + ", password=" + password + ", leader_Status="
				+ leader_Status + "]";
	}
	
	
	
	
	
	
}
